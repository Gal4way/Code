public class ChessPosition {
	public int Listi,Listj;
	
	public ChessPosition() {
		
	}
	public ChessPosition(int Listi,int Listj) {
		this.Listi=Listi;
		this.Listj=Listj;
	}
}
